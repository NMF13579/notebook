# Граница schema draft

`context-retrieval.schema.json` задаёт предложенный local value transport: QueryRequest, RetrievalResult, ErrorResult. Не является принятой public AOS schema и не копирует Task Brief, Authorization или Context Pack.

Поля — candidate HOW. Runtime обязан дополнительно проверить: реальные capture/source identities; policy/eligibility; совпадение `end_line >= start_line`; фактический digest/snippet; current source revision; согласованность `status`/items/mandatory omissions; max bytes для всего serialised envelope; отсутствие source leaks; поддержанность graph paths. `NO_MATCHES` допустим лишь при пустых items, но не означает absence в проекте; `RESULT` не допускает missing mandatory sources; неизвестная/старая binding не даёт current action context. `metrics` и `effects` должны быть измерениями, не заданными моделью заверениями.

JSON Schema integer проверяет численную целостность, а не лексическую форму JSON number. Если runtime boundary требует `type(value) is int`, loader отдельно отклоняет float `1.0`, bool-as-int, duplicate JSON keys и non-finite values. Приложенная схема сама не обеспечивает это правило.

Role и fact_class ортогональны. `owner_binding_ref` обязателен по смыслу для claim об accepted source и должен быть проверен actual owner; строка «accepted» либо hash сами не достаточны. Статусы принадлежат только output модуля, не изменяют core enums.

Source path является locator, не командой открытия. Pattern не sandbox, не symlink defence и не доказательство файловой identity. Безопасное чтение и output redaction принадлежат admitted adapter/host.

Примеры являются SYNTHETIC_FIXTURE. Они не отражают реальную Feature или Human decision. Semantic/vector mode отсутствует в v1 enum; его нельзя silently включать.
