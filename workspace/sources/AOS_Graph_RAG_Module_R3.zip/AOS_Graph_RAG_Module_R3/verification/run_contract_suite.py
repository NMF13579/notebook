#!/usr/bin/env python3
"""Run proposed acceptance cases against an explicitly supplied trusted adapter.

No adapter -> NOT_RUN (exit 3). This is a test harness, not an AOS runtime.
The adapter is test code: stdout is one JSON object, stdin has setup/action.
No command shell is used. Inspect a third-party adapter before running it.
A timeout halts subsequent cases; child descendants/effects may require cleanup
by the adapter owner. This harness is not a subprocess containment sandbox.
"""
from __future__ import annotations
import argparse
import json
import math
import subprocess
import sys
from pathlib import Path
from typing import Any

HERE = Path(__file__).resolve().parent

def parse_object(text: str) -> dict[str, Any]:
    def pairs(items: list[tuple[str, Any]]) -> dict[str, Any]:
        out: dict[str, Any] = {}
        for key, value in items:
            if key in out:
                raise ValueError('duplicate JSON key')
            out[key] = value
        return out
    value = json.loads(text, object_pairs_hook=pairs,
                       parse_constant=lambda _: (_ for _ in ()).throw(ValueError('non-finite number')))
    if not isinstance(value, dict):
        raise ValueError('response must be an object')
    return value

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--timeout', type=float, default=60.0,
                        help='Per-adapter-call seconds; proposed test budget, not a runtime guarantee')
    parser.add_argument('--case', action='append', default=[], help='Run only explicit case IDs')
    parser.add_argument('--adapter', nargs=argparse.REMAINDER,
                        help='Explicit trusted adapter command; place this option last')
    args = parser.parse_args()
    if not math.isfinite(args.timeout) or args.timeout <= 0:
        parser.error('--timeout must be positive')
    specification = parse_object((HERE / 'contract_cases.json').read_text(encoding='utf-8'))
    all_cases = specification['cases']
    requested = set(args.case)
    known = {case['id'] for case in all_cases}
    if requested - known:
        parser.error('Unknown case ID')
    cases = [c for c in all_cases if not requested or c['id'] in requested]
    if not args.adapter:
        print(json.dumps({'status':'NOT_RUN','scope':'runtime conformance',
                          'reason':'No implementation adapter supplied',
                          'cases_not_run':len(cases),'implementation_validation':'NOT_RUN'}, ensure_ascii=False, indent=2))
        return 3
    results = []
    for case in cases:
        payload = {key: case[key] for key in ('setup', 'action')}
        payload['case_id'] = case['id']
        result: dict[str, Any] = {'case_id':case['id']}
        try:
            completed = subprocess.run(args.adapter, input=json.dumps(payload, ensure_ascii=False),
                                       capture_output=True, text=True, encoding='utf-8',
                                       timeout=args.timeout, check=False, shell=False)
            if completed.returncode:
                result.update(status='FAIL',reason='Adapter exited nonzero',exit=completed.returncode)
            else:
                data = parse_object(completed.stdout)
                if data.get('status') == 'NOT_RUN':
                    result.update(status='NOT_RUN',reason=str(data.get('reason','Unspecified limitation'))[:500])
                elif data.get('status') != 'EXECUTED':
                    result.update(status='FAIL',reason='Missing EXECUTED/NOT_RUN adapter status')
                else:
                    observed, evidence = data.get('observations'), data.get('evidence')
                    if not isinstance(observed, dict) or not isinstance(evidence, dict):
                        raise ValueError('missing observations/evidence')
                    if not all(isinstance(evidence.get(k), str) and evidence[k].strip()
                               for k in ('subject','public_boundary','method')):
                        raise ValueError('missing subject/boundary/method')
                    mismatches = []
                    for key, expected in case['expected_observations'].items():
                        actual = observed.get(key)
                        if key not in observed or type(actual) is not type(expected) or actual != expected:
                            mismatches.append(key)
                    result.update(status='FAIL' if mismatches else 'PASS',
                                  mismatched_observation_keys=mismatches,
                                  evidence_attribution=evidence)
        except subprocess.TimeoutExpired:
            result.update(status='NOT_RUN',reason='Adapter exceeded test timeout; external effects require reconciliation')
        except (OSError, ValueError, TypeError) as exc:
            # Do not echo arbitrary adapter stderr or secret-bearing input/output.
            result.update(status='FAIL',reason=type(exc).__name__)
        results.append(result)
        if result.get('reason', '').startswith('Adapter exceeded test timeout'):
            for pending in cases[len(results):]:
                results.append({'case_id':pending['id'], 'status':'NOT_RUN',
                                'reason':'Stopped after prior adapter timeout; reconcile external effects first'})
            break
    status = ('FAIL' if any(r['status']=='FAIL' for r in results) else
              'BLOCKED' if any(r['status']=='NOT_RUN' for r in results) else 'PASS')
    print(json.dumps({'status':status,'scope':'adapter-reported conformance',
                      'independent_audit':'NOT_RUN','human_acceptance':'NOT_RUN',
                      'limitations':['A dishonest adapter can fabricate observations; independent audit must review and reproduce effects.'],
                      'cases':results},ensure_ascii=False,indent=2))
    return 1 if status=='FAIL' else 3 if status=='BLOCKED' else 0

if __name__ == '__main__':
    sys.exit(main())
