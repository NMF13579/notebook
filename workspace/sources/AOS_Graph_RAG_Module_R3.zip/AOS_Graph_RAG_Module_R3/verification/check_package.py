#!/usr/bin/env python3
"""Read-only checks of this proposal package. Not runtime validation."""
from __future__ import annotations
import copy
import hashlib
import json
import re
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def main() -> int:
    errors: list[str]=[]
    checks: dict[str, object]={}
    def load(name: str):
        def pairs(items):
            out={}
            for k,v in items:
                if k in out: raise ValueError('duplicate key')
                out[k]=v
            return out
        return json.loads((ROOT/name).read_text(encoding='utf-8'),object_pairs_hook=pairs,
                          parse_constant=lambda _: (_ for _ in ()).throw(ValueError('nonfinite')))
    json_files=list(ROOT.rglob('*.json'))
    for p in json_files:
        try: load(str(p.relative_to(ROOT)))
        except (ValueError,OSError) as e: errors.append(f'Invalid JSON {p.relative_to(ROOT)}: {type(e).__name__}')
    checks['json_files_parsed']=len(json_files)
    broken=[]
    for p in ROOT.glob('*.md'):
        for link in re.findall(r'\[[^\]\n]+\]\(([^)]+)\)',p.read_text()):
            link=link.split('#')[0]
            if not link or '://' in link: continue
            if not (p.parent/link).exists(): broken.append(f'{p.name}: {link}')
    errors+=broken;checks['relative_markdown_links']='PASS' if not broken else 'FAIL'
    graph_ids=set(re.findall(r'^\*\*(AC-\d{2})\b',(ROOT/'02_GRAPH_PRODUCT_CONTRACT.md').read_text(),re.M))
    rag_ids=set(re.findall(r'^\*\*(RA-\d{2})\b',(ROOT/'03_RETRIEVAL_PRODUCT_CONTRACT.md').read_text(),re.M))
    expected_graph={f'AC-{n:02}' for n in range(1,39)}
    expected_rag={f'RA-{n:02}' for n in range(1,25)}
    if graph_ids!=expected_graph or rag_ids!=expected_rag: errors.append('Acceptance ID inventory mismatch')
    suite=load('verification/contract_cases.json');cases=suite['cases']
    case_ids=[c['id'] for c in cases]
    if len(set(case_ids))!=len(case_ids):errors.append('Duplicate runtime case IDs')
    coverage=set()
    for c in cases:
        if not c.get('setup') or not c.get('action') or not c.get('expected_observations'):
            errors.append(f'Incomplete case {c["id"]}')
        coverage.update(c['acceptance'])
    if coverage!=graph_ids|rag_ids: errors.append('Uncovered or unknown acceptance criteria')
    checks.update(graph_criteria=len(graph_ids),retrieval_criteria=len(rag_ids),runtime_scenarios=len(cases),
                  criteria_to_scenarios='PASS' if coverage==graph_ids|rag_ids else 'FAIL')
    corpus=load('examples/corpus.fixture.json');result=load('examples/result.json')
    for hit in result['items']:
        s=hit['source'];text=corpus['files'][s['path']]
        if hashlib.sha256(text.encode()).hexdigest()!=s['revision']:errors.append('Fixture digest mismatch')
        if s['end_line']<s['start_line']:errors.append('Invalid example span')
        snippet=''.join(text.splitlines(keepends=True)[s['start_line']-1:s['end_line']])
        if snippet!=hit['snippet']:errors.append('Fixture snippet mismatch')
    wire=json.dumps(result,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
    if len(wire)!=result['metrics']['serialized_bytes']:errors.append('Serialized fixture size mismatch')
    if len(wire)>load('examples/query.json')['limits']['max_output_bytes']:errors.append('Fixture budget exceeded')
    checks['fixture_digest_span_and_size']='PASS' if not any('Fixture' in x or 'fixture' in x for x in errors) else 'FAIL'
    try:
        import jsonschema
    except ImportError:
        checks['json_schema_validation']='NOT_RUN: jsonschema not available; this is a documentation-check dependency, not runtime dependency'
    else:
        schema=load('schemas/context-retrieval.schema.json')
        jsonschema.Draft202012Validator.check_schema(schema)
        validator=jsonschema.Draft202012Validator(schema)
        positives=['examples/query.json','examples/result.json','examples/error.json']
        for n in positives:
            if list(validator.iter_errors(load(n))): errors.append(f'Schema rejected positive {n}')
        query=load('examples/query.json')
        neg=[]
        x=copy.deepcopy(query);x['surprise']=True;neg.append(x)
        x=copy.deepcopy(query);x['query']=' ';neg.append(x)
        x=copy.deepcopy(query);x['mode']='SEMANTIC';neg.append(x)
        x=copy.deepcopy(query);x['limits']['max_hits']=True;neg.append(x)
        x=copy.deepcopy(query);x['limits']['max_hits']=1.5;neg.append(x)
        x=copy.deepcopy(query);x['limits']['max_hops']=999;neg.append(x)
        x=copy.deepcopy(query);x['limits']['max_output_bytes']=1;neg.append(x)
        x=copy.deepcopy(query);del x['binding'];neg.append(x)
        x=copy.deepcopy(result);x['items'][0]['source']['revision']='wrong';neg.append(x)
        x=copy.deepcopy(result);x['items'][0]['source']['path']='../secret';neg.append(x)
        x=copy.deepcopy(result);x['items'][0]['source']['path']='/etc/passwd';neg.append(x)
        x=copy.deepcopy(result);x['effects']['network_calls']=1;neg.append(x)
        for idx,x in enumerate(neg,1):
            if not list(validator.iter_errors(x)): errors.append(f'Schema accepted negative {idx}')
        checks.update(json_schema_validation='PASS',schema_positive_examples=len(positives),schema_negative_examples=len(neg))
    checks.update(runtime_validation='NOT_RUN',installed_host_e2e='NOT_RUN',benchmark='NOT_RUN',independent_audit='NOT_RUN',human_acceptance='NOT_RUN')
    print(json.dumps({'status':'FAIL' if errors else 'PASS','scope':'DOCUMENTATION_AND_FIXTURE_STRUCTURE_ONLY',
                      'checks':checks,'errors':errors},ensure_ascii=False,indent=2))
    return 1 if errors else 0
if __name__=='__main__':
    sys.exit(main())
