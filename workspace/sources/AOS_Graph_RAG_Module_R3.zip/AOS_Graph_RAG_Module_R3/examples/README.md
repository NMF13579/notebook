# Примеры

Corpus, query, result и error — SYNTHETIC_FIXTURE, не output реализованного модуля. В `result.json` raw-byte digest соответствует строке `docs/export.md` из corpus fixture; `serialized_bytes` — длина compact sorted-key UTF-8 wire JSON, не форматированного example-файла.

Имена Feature/paths — вымышленные тестовые данные. Роль источника REFERENCE/REPORTED не превращается в Human acceptance. Python code внутри JSON — текст для будущего parser fixture; эта подготовка его не запускала.

Graph/Delta scenario semantics заданы в `verification/contract_cases.json`, сохранены из R2. Их full owner types должны быть построены реальным adapter; тестовые expected values не являются готовым сравнителем.
