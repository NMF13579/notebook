# ТЗ — модуль Graph + RAG для разработки · R3

**Primary class:** `CANDIDATE_TECHNICAL_SPEC`. **Статус:** `GENERATED_DRAFT`.
**Предмет:** HOW совместной поставки двух proposed capability contracts. Это не accepted Engineering Design: exact host/capture/save bindings и полный path inventory закрываются на существующей стадии проектирования. Ниже нет полномочий на реализацию.

Нормативное направление при будущих принятиях: **Product Contract → Engineering Design → implementation → Evidence**. Данный supporting draft не принимает upstream behavior. References обозначены в `07_SOURCES_AND_REVIEW.md`.

## 1. Что хорошо / риски / выбранный вариант

**Что хорошо:** у AOS уже есть derived project graph, backlog и pure Context Pack. R2 описал различие Target/Observed/Mapping/Delta; требуется композиция, а не новая система управления агентами. [R-04, R-07; P-02]

**Что вызывает вопросы:** полный AS-IS payload недоступен этой проверке; первый исполняемый host и доступный наблюдатель надо связать с actual owner. Наивное semantic matching может дать ложный drift, а переиндексация — стоить дороже direct search.

**Что сделать иначе:** не объединять всё в один knowledge graph. Общий capture, но отдельные searchable text, structural graph, target projection и comparator. Один модуль поставки; отключаемые внутренние capabilities. Никакой перенос whole Graphify/Sourcegraph/GraphRAG platform не выбран.

> Какой наблюдавшийся failure или дорогой необратимый риск оправдывает этот механизм?

Основания: повторный поиск, потеря контекста, stale maps и неверное смешение плана/реализации. Наименование технологии само по себе не основание. Первый bounded experiment — один выбранный участок проекта и одна задача; затем сравнение нескольких реальных задач по §15.

## 2. Scope первой полной версии

`LEXICAL_GRAPH_CONTEXT_V1` + Graph Work R3. Разрешённый локальный корпус; Markdown/text, поддержанные JSON metadata и Python syntax; текстовый поиск и явные typed relations; source-bound comparison; context packet; refresh; continuity; один работающий installed host route.

Начальная целевая ОС для проверки — macOS arm64 пользователя; **это предлагаемый профиль, не уже доказанная совместимость**. Python/toolchain берётся из действующего foundation при repository reconciliation. Другие ОС нельзя объявить поддержанными по одним fixtures.

Отложено: embeddings, vector DB, paid reranking, model-extracted edges, большой global summary, arbitrary-language call graph, scheduler, параллельное исполнение, generic plugin framework. Отложенное не требуется для PASS первого subset.

## 3. Runtime boundary

```text
existing user/agent host
  → explicit task/query/scope
  → allowed source capture
       ├─ lexical units/index → retrieval candidates
       ├─ observed typed relations → bounded graph expansion
       └─ applicable design sources → target + mapping
                                  ↓
                        targeted comparison → Delta
                                  ↓
retrieved original fragments + mandatory owner refs + selected Delta
  → existing Context Pack boundary
  → Work Packet / source-grounded answer by existing host
  → existing development workflow (outside module)
  → report references → CHECK/REFRESH before next use
```

Не каждый query проходит все ветки. `find` может обойтись retrieval; `compare` требует coverage, а не top-k. `packet` связывает конкретную выбранную задачу; `resume` не повторяет неизвестное действие.

**Локальное чтение не должно проходить через LLM для каждого файла.** Host передаёт scope и разрешённый инструменту доступ; deterministic tool читает/индексирует corpus внутри своей разрешённой границы. Модели передаются только query и отобранные snippets. Semantic interpretation prose выполняется existing agent лишь там, где нет явной структуры, и остаётся оплачиваемым proposal.

Точный read primitive — existing admitted interface либо отдельный bounded unprivileged capture adapter в принятом Design. Он не выдаёт себе native/protected access и не заменяет FTR-009. Публичный FTR-009 в проверенном README остаётся BLOCKED-only; обход не допускается. [R-08]

## 4. Владение, reuse и существующая карта

| Данные/граница | Роль модуля |
|---|---|
| Task/backlog/selection | Читать результаты действующего owner; не пересоздавать task state machine |
| Expected semantics | Проекция применимых Product/Design/ADR sections; acceptance файла не принимает его DRAFT sections |
| Code/material facts | Проверенное наблюдение exact bytes/subject, не output LLM |
| Existing AS-IS map | Импорт поддержанного формата, сохранение IDs, направлений и provenance; completeness перепроверяется |
| Context Pack | Использовать `build_context_pack(request, sources)`; ranking/capture остаются снаружи pure функции |
| Permissions/results/review | Ссылки на existing owner; JSON поле `accepted: true` не становится proof |
| Search index/maps/cache | Производные, удаляемые и пересобираемые представления |
| Human decisions / source artifacts | Не изменять при refresh/search/compare |

У существующего project graph `PRODUCES` = supplier → data, `CONSUMES` = consumer → data. Для запроса «кто потребляет результат поставщика» пройти PRODUCES вперёд к data, затем CONSUMES **в обратном направлении** к consumer; не переворачивать хранимые рёбра. [R-04]

Импортер не обязан загрузить всю research map в runtime и не делает `development/` runtime dependency. Для installed продукта карта строится из его собственных разрешённых источников. Unsupported import → ограничение плюс supported local extraction, не новый дублирующий registry.

## 5. Общий corpus и source identities

Каждое наблюдение связывается с `project_id`, `worktree_identity`, `scope_id`, `capture_id`. Git `HEAD` — дополнительный атрибут, не полный identity. При отсутствии Git поддерживается file-snapshot view, без Git readiness claims.

На разрешённый источник хранить: repository-relative locator; raw-byte digest; размер; диапазон строк/другой точный locator; роль; claim class; подтверждающий owner ref при известной authority. На derived unit дополнительно: extractor/chunker version и config identity. Чувствительные locators не сериализуются в user-visible ошибки.

Общая capture-generation содержит source manifest и coverage. Каждое downstream представление ссылается на **свой набор input revisions**, а не общий `fresh: true`. Нельзя смешать lexical index worktree A и graph worktree B либо свежий text и старые edges.

Формат `schemas/context-retrieval.schema.json` — самостоятельный draft value envelope, **не копия** upstream Task Brief/Auth/Context Pack schema. References к upstream несут identity; их подлинность/применимость проверяет текущий owner. JSON Schema проверяет форму, не доступ, authority, свежесть или семантику.

## 6. Capture и согласованность

1. Определить explicit include scope и exclusion policy. По умолчанию исключить credentials, `.git`, зависимости/build caches, binary/oversized/unsupported files, собственные generated cache/output. Не раскрывать список чувствительных исключений.
2. Получить inventory **всего выбранного scope**, включая разрешённые untracked файлы. Только повторное чтение старого manifest не обнаружит добавления.
3. Читать regular sources через разрешённый bounded adapter; не следовать symlink за границу, не исполнять code/macros, не загружать hooks. Ошибка чтения или unsupported content — coverage gap.
4. Зафиксировать фактически прочитанные bytes и input revisions. Для meaningful absence claim требуется достаточная полнота именно соответствующего predicate, не «все файлы когда-либо».
5. Использовать immutable/frozen subject, когда он предоставлен existing owner. Иначе обозначить interval observation и обнаруженные изменения; проверка до/после снижает риск смешения, но не доказывает атомарный filesystem snapshot при произвольном concurrent writer.
6. При material instability не публиковать affected current claim. Сохранить historical view и предложить bounded recapture. **Не объявлять двойной stat полной гарантией consistency.**

Чтение может влиять на access time. Обещание «не меняем source bytes» не заменяет строгую zero-write гарантию другой capability. Сам модуль не создаёт новый OS sandbox; закрытый/недоступный read route остаётся закрытым.

## 7. Chunking и lexical index

**Source units:** Markdown — заголовок/секция с локатором; Python — definition/import или ограниченный line window; JSON — поддержанные ключи/explicit refs плюс source span. Raw bytes/digest сохраняются, отображаемый text не переписывается под запрос. Большая секция делится по строкам; heading ancestry остаётся metadata. Chunk не должен отрывать отрицание или обязательное ограничение от правила; иначе включается более широкий span либо packet неполон.

**Базовая реализация-кандидат:** transient inverted index в памяти и сохраняемый разрешённый source-bound reference bundle. Для маленького scope допустим direct scan. Не строить собственный масштабируемый поисковый сервер. SQLite FTS5 — возможный будущий локальный backend, не mandatory dependency; его external-content index требует отдельной синхронизации с content. [W-04]

**Предлагаемый deterministic scorer v1:**

- Exact ID/path/source selector имеет отдельный приоритетный канал и сохраняет регистр/исходную identity.
- Для lexical matching выполнить Unicode-aware casefold только search tokens, разбить identifiers на полное имя и части (snake/camel); не менять ID источника.
- Кандидаты сортировать по exact-match, числу разных найденных query terms, затем сумме `1 + log((N+1)/(df+1))` для найденных terms; tie-break по source identity и span. Это собственная простая эвристика-кандидат, **не заявление об оптимальности/BM25**.
- Для RU/EN: сохранять Unicode и technical identifiers; явно заданный project glossary можно использовать как query hints с provenance. Не обещать cross-language semantic recall без проверки.
- Не оценивать source authority числом relevance. Два противоречащих владельца нельзя разрешать поисковым score.

Сначала проверить этот простой вариант против direct search. BM25/vector/learned reranker вводить лишь при конкретном recall/ranking failure и сравнении полной стоимости.

## 8. Graph extraction и navigation

Не существует одного взаимозаменяемого «графа»:

- **Project/Resource Graph:** files, sections, contracts, data, symbols, tests, owners и typed relations.
- **Target Map:** ожидаемые properties из применимых источников, включая modality и current/future applicability.
- **Observed Map:** извлечённая структура/ссылки и отдельно execution Evidence refs.
- **Task DAG:** зависимости работы существующего backlog owner; import cycles не являются task cycle.

Initial extraction: `CONTAINS`, `REFERENCES` для explicit links/IDs; Python definition и direct import syntax в объявленном package-root mapping. Если импорт однозначно не разрешается, хранить declaration/limitation, не придумывать runtime edge. `from pkg import x`, conditional imports, alias, dynamic import и monkey-patching не дают автоматически точный `CALLS`/runtime dependency.

Полные `IMPLEMENTS`/`TESTS`/`OWNED_BY` только из явной применимой связи/metadata; по имени файла — hint, не proof. Рёбра различают `DECLARED`, `EXTRACTED`, `INFERRED`; это происхождение, не authority. Agent inference не используется как обязательное основание comparator.

**Graph-assisted retrieval:** exact/lexical hits → mapped nodes → допустимые typed edges по указанному направлению → связанные source units → bounded dedup/ranking. Initial defaults-кандидаты: максимум 1 hop, 20 seed units, 50 explored graph nodes. Это стартовые настройки эксперимента, не product guarantees; лимиты по запросу задаёт поддержанный профиль, truncated traversal видим.

Graph rank может помогать выбрать полезные фрагменты, как в repo-map Aider; нельзя из важности узла делать conclusion о корректности или полноте. [W-01]

## 9. Retrieval pipeline

Предлагаемая pure операция:

```text
retrieve(QueryRequest, CorpusCapture, OptionalGraphView) → RetrievalResult
```

Порядок: validate → restrict eligible corpus → check needed freshness → collect exact anchors → lexical candidates → bounded allowed graph expansion → verify selected source revisions → deduplicate by identity/revision/span/role → reserve mandatory context → fill optional budget → render source refs/reasons/coverage/limitations.

Scope/exclusions применяются **до graph traversal и ранжирования**. Нельзя проходить через скрытый узел и раскрывать его существование в path/reason. Query не является произвольным shell/SQL expression. В будущих SQL backends параметры не конкатенируются в исполняемый запрос.

Mandatory items: current task owner refs, применимые constraints и acceptance, требуемые source bindings. Список приходит от task/host routing, не строится только по поисковой популярности. Если mandatory item недоступен, результат `PARTIAL`, а не полный action packet.

Default budget: exact UTF-8 byte limit для serialized retrieval result; когда доступен pinned host tokenizer, дополнительно его token budget. Не оценивать Russian tokens фиксированным «4 символа = токен» как точное ограничение. Diagnostic envelope тоже входит в размер. Слишком малый budget, не вмещающий minimum error envelope, отклоняется до обычной выдачи.

Content дедуплицировать осторожно: одинаковый текст в accepted artifact и historical note — разные атрибуции. Conflicts не скрывать.

## 10. Target / Observed / Mapping / Delta

Initial predicates: `FILE_EXISTS`, `EXPLICIT_LINK`, `PY_STATIC_IMPORT`, `CHECK_RESULT_REF`. Возможность поддержана только в объявленном scope/extractor profile.

Target item: expectation identity; authoritative source section/ref; predicate; modality `REQUIRED/FORBIDDEN/OPTIONAL/GUIDANCE`; applicability current/future; declared mapping selector. One-to-many mapping допустимо как явный конечный source-set. Неоднозначные альтернативы не превращаются в «выбран первый».

Сравнение выполняется **не по retrieved top-k**, а по достаточному наблюдению mapped scope. Позитивный witness может подтвердить конкретное наличие при неполном общем corpus. Отрицание требует достаточного покрытия именно проверяемой области/метода.

| Delta classification | Значение |
|---|---|
| `MATCHED` | Конкретное сопоставимое свойство подтверждено; не общий PASS |
| `MISSING_EXPECTED` | Required/current свойство отсутствует при достаточном отрицательном наблюдении |
| `FORBIDDEN_PRESENT` | Есть current witness применимого запрета |
| `UNMODELED` | Не описано target; не дефект без исчерпывающей границы/запрета |
| `PLANNED_DIFFERENCE` | Подтверждённое отличие относится к future scope |
| `OPTIONAL_ABSENT` | Optional свойство достоверно отсутствует |
| `UNVERIFIED` | Нет достаточных актуальных/сопоставимых оснований |
| `CONFLICT` | Material противоречие источников/observations |

Freshness, coverage и applicability — отдельные оси, сохраняемые из R2. Draft expectation или unconfirmed mapping дают exploratory view, не confirmed drift. Test file presence ≠ test run; existing result Evidence применимо лишь к exact subject.

Routing Delta: recapture / correct projection / clarify mapping / предложить owner design correction / предложить bounded implementation correction. Ни один вариант не исполняется автоматически и не меняет canonical expectation.

## 11. CHECK, REFRESH и инвалидация

Совместиться с уже найденной CHECK/REFRESH boundary проекта: CHECK не пишет, REFRESH только в явной write boundary; pending refresh видим. Не добавлять watcher или второй реестр pending work. [R-06]

Триггеры: request `inspect/find/compare/packet/resume`; полученный terminal report перед следующим использованием. Это proposed module operation names, не уже существующие команды AOS. Historical-only просмотр не требует полного refresh, но ясно помечен.

| Изменение | Что пересмотреть |
|---|---|
| File bytes | Его chunks, extracted edges, зависящие selected packets/Delta |
| Добавление/удаление пути | Scope inventory и отрицательные/полнота assertions; старого reverse-edge списка недостаточно |
| Перемещение | Старый locator удалён, новый добавлен; logical identity не переносится без основания |
| Target/mapping revision | Target projection и зависимый Delta, не переписывая Observed truth |
| Exclusion/access policy | Eligibility всех derived views; запрещённые snippets не возвращаются до очистки |
| Extractor/tokenizer/chunker revision | Только зависящие representations; при неизвестном impact — bounded rebuild scope |
| Другой worktree/scope | Новый capture binding; кэш другого subject не считается свежим |

**Условие cache reuse:** совпадают source revisions, разрешённый scope/policy, extractor/config и зависимости конкретного результата. `HEAD` или mtime/size отдельно недостаточны. Warm query может не повторять parsing/индексацию, но всё равно оплачивает необходимую freshness observation; не обещать нулевой I/O.

После source change возможна partial актуальность: lexical ready, graph stale. Разрешить lexical-only query с limitation; запретить соответствующий current graph claim. Cached negative conclusions инвалидировать и при новом входящем отношении из добавленного файла.

## 12. Storage, effects и recovery

Derived graph/index не владеют accepted facts. По умолчанию in-memory computation; сохранение reference bundle/cache — отдельный явно разрешённый effect вне observed source corpus. Предлагаемая user-owned namespace: `project/graph-work/`; exact allocation обязан учитывать installer/owner policies и existing files.

Storage option первой реализации — versioned plain files без server/DB. Immutable payload → complete manifest → publish current reference только после подтверждённого сохранения. Concurrent edit обнаружить по ожидаемой revision через admitted writer primitive, не «последняя запись победила». Не выдумывать наличие atomic compare-and-swap у текущего host: при отсутствии такого примитива выбрать existing safe single-writer route либо сохранить несвязанную candidate revision и показать конфликт; не менять shared current pointer.

| Operation | Чтение | Запись/сеть |
|---|---|---|
| `CHECK` | Разрешённый source/current binding | Нет записи и сети |
| `find/compare/packet` | Capture/valid cache | Только stdout/returned value; persistence не implicit |
| `REFRESH` с output | Разрешённый corpus | Только explicitly allowed derived destination; source bytes не меняются |
| `resume` | Reference bundle + fresh observations | Не replay actions; сохранение — отдельный разрешённый effect |
| purge derived data | Только owner namespace | Только заявленный delete/write scope; чужие sources/records не удаляются |

Сбой до publish сохраняет последнюю подтверждённую revision. При повреждении cache — direct source fallback или rebuild в разрешённой области. Продолжение без прошлых chats возможно только если необходимые пользовательские refs действительно сохранены; наличие object в памяти не называется persistence.

Privacy reclassification немедленно ограничивает выдачу. Удаление persisted sensitive copies выполняется только в разрешённой собственнику cache boundary; невозможность purge отображается без раскрытия содержимого. Source excludes распространяются на embeddings и telemetry в будущем.

## 13. Context Packet и работа агента

Пакет содержит task/goal refs, выбранные source units, mandatory owner refs, relevant Delta witnesses, явно missing inputs, coverage/freshness, budget/usage metadata и одно candidate next action. Permissions — только refs, не generated grant.

Для FTR-016 подготовить `ContextSource` с точными content/reference/identity/authority/freshness; вызвать existing `build_context_pack`. Не менять его semantic selection только ради нового ranking. Current source сохраняет duplicate conflicting sources отдельно и перечисляет limitations. [R-07]

Host получает компактный блок в порядке: задача/границы → применимые norms → observations → evidence → reference/hypotheses. Для утверждений из источников — локаторы/ревизии; вывод агента помечен inference. Никакой карты целиком в каждом prompt. Host tools продолжают существующую разработку, но module не добавляет dispatch API.

Структурный retrieval/reconciliation не вызывает новую LLM. Existing host может один раз интерпретировать естественный запрос и потом генерировать ответ/код, затраты видимы. Не вводить автоматический цикл «не нашли → ещё один агент → ещё одна база → ещё одна модель».

## 14. Optional semantic profile — после базового измерения

Это specification extension proposal, не принятый v1 scope. Причина запуска: lexical+graph пропускает нужный материал из-за терминологического различия, подтверждённого benchmark.

Будущее расширение: explicit opt-in → approved local/remote embedding policy → embedding только разрешённых изменённых chunks → key `(source_revision, span, chunker, embedding_model_revision)` → vector candidates + lexical candidates → rank fusion → те же mandatory/freshness/privacy filters → тот же Context Packet.

Не смешивать embeddings разных model revisions/dimensions. Не переносить vector similarity в Target↔Observed identity. Remote profile требует exact data/budget/provider decision, видимой передачи и измеренного privacy/cost эффекта. Local profile тоже имеет CPU/memory/installation cost. Нет silent model download или remote fallback.

Microsoft GraphRAG иллюстрирует сочетание graph и raw text, но его summarization/indexing workflows не становятся обязательными. Его `DRIFT Search` — название retrieval technique, **не наш architecture drift detector**. [W-02, W-03, W-06]

## 15. Экономика и критерий выбора сложности

Считать отдельно human coordination/review time, model input/output/cached usage, compute/I/O, cold build, refresh, repeated attempts и окончательные дефекты. Цена API и квота подписки — разные показатели. При неизвестных данных money total `UNKNOWN`.

```text
C_per_validated_result = (setup + refresh + all_attempts + review + repair) / validated_results
```

При нуле validated results ratio не определён. Уменьшение числа прочитанных tokens не считается выигрышем при росте critical omissions/rework. Сравнивать cold и warm сценарии; не выдавать заранее идеальную карту только экспериментальному варианту.

Сначала direct search vs lexical+graph на одном scope, затем минимум набор случаев из verification. Orienting target: 20% improvement измеренной медианы coordination effort или полной наблюдаемой стоимости без material quality regression. Это предложенный критерий pilot, не доказанная экономия и не новый governance gate.

## 16. Предварительные integration anchors и изменения

Existing anchors прочитаны на pinned commit; `[NEW]` paths ниже — **предложения**, не найденные файлы и не allowlist execution. Final collision/schema/owner inventory закрывается до принятия Engineering Design.

| Anchor/path | Disposition / назначение |
|---|---|
| `aos/src/aos/application/context_pack.py` | READ/REUSE; pure context owner |
| `aos/src/aos/application/backlog.py` | REUSE после exact signature сверки; не новый backlog |
| `docs/architecture/02_SYSTEM_ARCHITECTURE.md` §18 | READ; vocabulary и derived graph boundary |
| `development/research/as-is-project-map/AS_IS_PROJECT_MAP.md` | READ в docs/research; не runtime dependency |
| `aos/src/aos/domain/graph_work.py` | `[NEW]` candidate, graph comparison values |
| `aos/src/aos/application/graph_work.py` | `[NEW]` candidate, pure comparator |
| `aos/src/aos/domain/context_retrieval.py` | `[NEW]` candidate, retrieval values |
| `aos/src/aos/application/context_retrieval.py` | `[NEW]` candidate, lexical/graph/context selection |
| `aos/src/aos/adapters/graph_context.py` | `[NEW]` candidate, transport/composition; exact read/write boundary remains IG-02 |
| `aos/src/aos/cli.py` | `[MODIFY]` only narrow handler, if chosen public interface |
| `aos/workflows/GRAPH_CONTEXT.md`, `aos/docs/GRAPH_CONTEXT.md` | `[NEW]` candidate: one portable supported-host workflow/help |
| `aos/schemas/context-retrieval.schema.json` | `[NEW]` candidate wire schema; package draft must reconcile owner types |
| `aos/MANIFEST.txt`, selftest, integration tests | `[MODIFY/NEW]` exact inventory closed in final Design; no wildcard authorization |

Если existing owner уже выполняет нужную функцию в том же scope, использовать его; не создавать все предложенные files механически. Не изменять root lifecycle, preflight, permissions или глобальные result enums ради модуля.

## 17. Ordered vertical outcomes — proposal, не execution mandate

| Срез | Сквозной результат | Что реально нужно | Что не требуется |
|---|---|---|---|
| S1 `LOCAL_CONTEXT` | В установленном host query → allowed capture → exact/lexical fragments → source-grounded Context Packet | capture, existing context integration, публичный путь | Полный граф, embeddings |
| S2 `LINKED_CONTEXT` | По найденному источнику получены поддержанные typed neighbors и relevant tests/contracts | S1, граф/импортер, bounded expansion | Target completeness, scheduler |
| S3 `TARGET_OBSERVED` | Для малого target получен объяснимый Delta и appropriate next packet | Достаточные observations/mapping, graph Contract | Advanced retrieval, новый executor |
| S4 `CONTINUITY_AND_PRODUCT` | Dirty changes/new session → свежий packet, safe save/disable, installed full journey и измеренные затраты | Согласованный writer/host, все required AC | Generic module framework, несколько агентов |

Initial proposed slice S1. Это общая последовательность результата пакета; accepted feature lifecycle и inter-feature переходы принадлежат current owner. Она **не автоматически активирует FTR-017 и Graph по одной команде**. Agent готовит отдельные exact Designs/acceptance mappings двух Feature scopes; shared technical HOW не создаёт mutual normative dependency.

## 18. Remaining gaps — только затронутые действия

| ID | Unknown / почему важно | Одно resolution action |
|---|---|---|
| IG-01 | Полная actual AS-IS representation/IDs не прочитана из-за tool fetch failure | Локально прочитать §8 и payload, определить supported import без переноса всего research файла |
| IG-02 | Exact safe local capture и scoped save/atomic-publication primitive | Найти current public owner/host; доказать bounded capture/save на disposable subject до admission |
| IG-03 | Первый поддержанный installed host/tokenizer и его transport | Выбрать один существующий host, связать commands/tool permissions, провести new-process E2E |
| IG-04 | Окончательные new/modify paths и serializers двух capability contracts | После принятия поведения закрыть inventory/compatibility в existing Engineering Design |
| IG-05 | Полная стоимость и quality benefit | Выполнить ограниченный A/B/C benchmark, включая cold setup и failures |

Эти unknowns не препятствуют docs-only импорту и безопасному read-only анализу. Они запрещают только необоснованные заявления `implementation-ready`, `supported`, `validated`, `cheaper`. Не заменять их новым Control Plane или цепочкой gates.
