# AOS — Graph + RAG Development Context · R3

**Дата:** 2026-09-14. **Статус всего пакета:** `GENERATED_DRAFT`.
**Назначение:** документация для внесения в репозиторий и отдельного последующего решения о разработке. Репозиторий, product runtime и Git не изменены этой подготовкой.

## Вывод

Поставлять **один отключаемый first-party модуль**: поиск контекста + графовые связи + Target/Observed/Mapping/Delta + задание существующему агенту. Сохранить **два отдельных контракта поведения**: графовая capability и retrieval `FTR-017`. Один пакет не означает одну неразделимую Feature или обязательный vector backend.

Первый вариант — **graph-assisted RAG без отдельного модельного посредника**. Он находит исходные фрагменты лексически, расширяет их по обоснованным связям и передаёт существующему агенту. Генерация остаётся у этого агента. Это не реализация Microsoft GraphRAG и не перенос Graphify.

## Что реально найдено

Проверен удалённый `NMF13579/AOS-3`, ветка `dev`, commit `e99cc3ee03128deb4506bc268839ebd1f52a3f3a`, tree `cd209a723a8b3ec0ac1374a04a40fda149b10e1c`. Это снимок удалённой ветки, не наблюдение local worktree пользователя. [R-01]

- В актуальном каталоге — 31 Feature, включая `FTR-017`; отдельная коробочная Graph Work capability в показанном индексе **не найдена**. Поиск exact `CAND-GRAPH-WORK-001` дал 0 результатов; это ограниченный поиск, не доказательство отсутствия во всех ветках. [R-03]
- **Проектный граф уже существует как архитектурное направление и AS-IS навигация разработки AOS-3.** В §18 архитектуры перечислены сценарии, фичи, контракты, данные, компоненты, ресурсы, профили и проверки. Это не выбранная коробочная capability для всех пользовательских репозиториев. [R-04]
- В `ARTIFACT_PROFILES.md` уже есть экспериментальная таблица cross-feature стыков. Новый пакет не создаёт второй такой нормативный owner. [R-05]
- Во вложениях есть `CAND-GRAPH-WORK-001`, Graph Work Companion R2, `GENERATED_DRAFT`. **Продолжаем его как R3**, а не создаём дубликат. Номер `FTR-*` не резервируется. [P-02]

Полное содержимое большого AS-IS файла получить не удалось; его фактический формат и полный набор IDs требуют локальной сверки. Частные runtime-гарантии из недоступного файла не придуманы.

## Что открыть

| Файл | Предмет |
|---|---|
| [01_FEATURE_PASSPORT.md](01_FEATURE_PASSPORT.md) | Graph Feature Candidate, reuse существующего графа, границы с FTR-017/021/007 |
| [02_GRAPH_PRODUCT_CONTRACT.md](02_GRAPH_PRODUCT_CONTRACT.md) | ЧТО делает Graph Work; R2 AC-01–36 сохранены, добавлены AC-37–38 |
| [03_RETRIEVAL_PRODUCT_CONTRACT.md](03_RETRIEVAL_PRODUCT_CONTRACT.md) | ЧТО делает предлагаемый bounded subset FTR-017; отдельный acceptance subject |
| [04_MODULE_TZ.md](04_MODULE_TZ.md) | ТЗ: capture, индексация, связи, retrieval, Delta, freshness, cache, context, effects, интеграция |
| [05_VERIFICATION_AND_BENCHMARK.md](05_VERIFICATION_AND_BENCHMARK.md) | Приёмка, негативные сценарии, E2E и сравнение стоимости/качества |
| [06_REPO_HANDOFF.md](06_REPO_HANDOFF.md) | Docs-only перенос и отдельно будущая команда запуска; без скрытого execution |
| [07_SOURCES_AND_REVIEW.md](07_SOURCES_AND_REVIEW.md) | Подтверждённые источники, новизна относительно R2, риски и remaining gaps |

`schemas/` не является owner Product behavior; схема — технический кандидат wire-format.
`verification/` содержит исполняемый harness и спецификации случаев, **не реализацию модуля**. Адаптер реального AOS отсутствует, runtime `NOT_RUN`.

## Scope первой версии

Входит: один разрешённый local corpus; Markdown/text + явные JSON references + ограниченная Python static structure; direct/lexical retrieval; bounded graph expansion; две различимые карты и объяснимое сравнение; freshness по месту использования; Context/Work Packet; один заявленный host; отключение и fallback.

Не входит: свой агент или scheduler; automatic task activation; paid extraction/rewriting/reranking; vector DB; cloud upload; daemon/watchers; автоматическая починка по Delta; новый gate/lifecycle; полный call/data-flow analysis. Embeddings — **отдельное optional расширение после измерения**, не условие завершения v1.

## Статус и один следующий action

```yaml
candidate_id: CAND-GRAPH-WORK-001
feature_id: UNASSIGNED
related_existing_feature: FTR-017
human_direction: DOCUMENTATION_PREPARATION
human_disposition: UNDECIDED
product_contract_acceptance: NOT_RUN
engineering_design_acceptance: NOT_RUN
repository_write: NOT_RUN
runtime_implementation: NOT_RUN
runtime_validation: NOT_RUN
benchmark: NOT_RUN
```

Уверенность **высокая** в разделении retrieval/graph/reconciliation: разные результаты и критерии доказательства. Уверенность **средняя** в стоимости интеграции: capture/save/host bindings ещё не закрыты. Экономический эффект — `UNKNOWN`.

Следующий bounded action — docs-only reconciliation/import по `06_REPO_HANDOFF.md`, с проверкой existing graph IDs и актуального inventory. Не запускать сборку только потому, что документы находятся в репозитории.
