# Источники, синтез и review R3

**Дата:** 2026-09-14. **Assessment:** `SYNTHESIZED / PROPOSAL`. Это не независимый аудит реализации.

## 1. Человеческое направление и границы

Текущий запрос: сформировать графовую фичу, если её нет, и ТЗ Graph + RAG модуля для эффективной качественной разработки. Предыдущие сообщения уточняют: коробочная поставка; отдельная команда запуска сборки; две карты «запроектировано/наблюдается»; синхронизация; общий модуль без слияния retrieval и graph semantics.

Это `HUMAN_CONFIRMED_DIRECTION` подготовки, не acceptance exact technical design. Все выбранные HOW, budgets и названия новых runtime файлов — предложения.

## 2. Материалы чата/Project

| ID | Источник | Что поддерживает |
|---|---|---|
| P-01 | `00_Core.md` (mounted `00_Core.md.txt`), §§5–13 | Fact-class authority, source precedence, safety, separation of acceptance/execution |
| P-02 | `AOS_Graph_Work_Feature_Candidate_R2.zip`, Product Contract/Design/tests | Target/Observed/Mapping/Delta и AC-01–36; draft, не accepted Feature |
| P-03 | `AOS_RAG_and_Graphs_Module_Analysis.md`, 2026-09-14 | Общая поставка, раздельные retrieval/compare, optional semantic expansion; supporting synthesis |
| P-04 | `06_Features.md` (mounted `06_Features.txt`), FTR-007/016/017/021/026 | Accepted inventory capability boundaries; старые item statuses не заменяют current repo decisions |

Точные SHA-256 доступных исходных attachment bytes записаны в `sources/source_manifest.json`. Полные canonical docs не размножаются внутри модуля. Пакет не меняет семь Project owners.

## 3. Прямое наблюдение текущего repository

Все pinned file locators ниже относятся к `NMF13579/AOS-3@e99cc3ee03128deb4506bc268839ebd1f52a3f3a`; read-only доступ через GitHub connector. Local state/другие ветки не наблюдались.

| ID | Path / scope | Finding и ограничение |
|---|---|---|
| R-01 | `dev` branch endpoint | HEAD `e99cc3ee03128deb4506bc268839ebd1f52a3f3a`, tree `cd209a723a8b3ec0ac1374a04a40fda149b10e1c`; наблюдение, не product acceptance |
| R-02 | `AGENTS.md` | Router owners, docs/development split, portable aos/, no authority from bootstrap |
| R-03 | `docs/product/06_FEATURES.md` index; exact code search `CAND-GRAPH-WORK-001` | Индекс показывает 31 Feature и FTR-017, FTR-031 уже занят. Отдельная boxed Graph entry не найдена в показанном индексе; exact candidate search = 0. Это ограниченный `NOT_FOUND`, не exhaustive runtime absence proof |
| R-04 | `docs/architecture/02_SYSTEM_ARCHITECTURE.md`, §18 | Existing project graph для разработки AOS-3; derived-only; сохранение IDs/vocabulary; PRODUCES/CONSUMES directions. Ответ большого файла усечён; использованы только реально видимые положения |
| R-05 | `ARTIFACT_PROFILES.md` | One normative subject per artifact, WHAT/HOW split; experimental cross-feature table already exists |
| R-06 | Search excerpt `FEATURE_DEVELOPMENT_CYCLE.md` around AS_IS_PROJECT_MAP | CHECK no-write; REFRESH explicit boundary; pending refresh и concurrent edit, без watcher. Полная §8 AS-IS не проверена |
| R-07 | `aos/src/aos/application/context_pack.py` | `build_context_pack(request, sources)` работает с supplied values; exclusions/limitations/conflicts сохраняются. Runtime не запускался |
| R-08 | `aos/README.md` | Portable source/host boundary; backlog output не activates tasks; current public FTR-009 остаётся BLOCKED-only и не даёт access handle |

Большой `development/research/as-is-project-map/AS_IS_PROJECT_MAP.md` не прочитан: GitHub fetch вернул HTTP 400 / too large or unsupported. Статус **`BLOCKED_REFERENCE_ACCESS` для чтения payload**, не для всей подготовки. Нельзя утверждать, что проверена его schema, полнота, cache invalidation implementation или runtime correctness.

Pinned repository URL base:

```text
https://github.com/NMF13579/AOS-3/tree/e99cc3ee03128deb4506bc268839ebd1f52a3f3a
```

## 4. Открытые первичные источники

**W-01 — Aider: Repository map.** Официальная документация описывает карту definitions/signatures и отбор релевантной части по графу зависимостей в пределах контекста. Берём принцип компактной навигации, не claims экономии на AOS, не весь Aider runtime.

```text
https://aider.chat/docs/repomap.html
```

**W-02 — Microsoft GraphRAG: Local Search.** Объединяет structured graph data и исходные text chunks, отбирая контекст для ответа. Берём graph-assisted source selection. Полная extraction/community stack и отдельный answer model не становятся зависимостями AOS.

```text
https://microsoft.github.io/graphrag/query/local_search/
```

**W-03 — Microsoft Learn: RAG in Azure AI Search.** Classic RAG отделяет поиск от последующей генерации; документация описывает keyword/vector/hybrid варианты. Это основание рассматривать non-vector retrieval как рабочую форму RAG, а не обещание Azure-like возможностей без реализации.

```text
https://learn.microsoft.com/en-us/azure/search/retrieval-augmented-generation-overview
```

**W-04 — SQLite FTS5.** Поддерживает full-text indexing/ranking. External-content таблицы требуют согласованности индекса с исходной content table; triggers не восстанавливают автоматически ранее отсутствовавшее содержимое. Это reference варианта backend и напоминание про invalidation, не выбор SQLite foundation.

```text
https://www.sqlite.org/fts5.html
```

**W-05 — ArchUnit.** Проверяет архитектурные зависимости/layers/cycles Java по bytecode. Берём идею проверяемого architectural predicate. Не переносим bytecode guarantees на Python syntax или source retrieval; Java библиотека не нужна модулю.

```text
https://www.archunit.org/
```

**W-06 — Microsoft GraphRAG: Methods и DRIFT Search.** Разные indexing methods имеют разные computational/quality trade-offs. DRIFT — Dynamic Reasoning and Inference with Flexible Traversal: retrieval method, не сверка кода с проектным дизайном.

```text
https://microsoft.github.io/graphrag/index/methods/
https://microsoft.github.io/graphrag/query/drift_search/
```

Все W-источники проверены 2026-09-14. Они используются как `REFERENCE`, не как normative authority над AOS. Код этих проектов в пакет не копировался. Graphify/SCIP/Zoekt остаются обсуждавшимися references; их implementation/security audit в R3 не выполнен, прежние численные рейтинги из чата не использованы как evidence.

## 5. Что изменено относительно R2

| Изменение | Основание и статус |
|---|---|
| Graph R3 продолжает прежний candidate, AC-01–36 сохранены | Не создавать duplicate Feature; R2 никуда не «принят автоматически» |
| Graph AC-37–38 | Явная граница retrieval ≠ comparator и импорт existing map |
| Отдельный FTR-017 bounded contract | Запрос совместного модуля не должен растворять поведение retrieval в HOW графовой Feature |
| Shared allowed capture и source identities | Уменьшить повторное чтение; отдельная свежесть downstream views |
| Базовый RAG включает lexical + graph → existing host | Избежать unnecessary paid intermediary и vector platform |
| Наличие existing project graph признано | Новое current repository observation; старый тезис «карты нет» не переносится |
| Чёткие capture/storage/host gaps | Не объявлять supplied-values unit test коробочной работой |

## 6. BLIND-CHECK — конкретные риски решения

### ⚠️ BLIND SPOT — PREMATURE ABSTRACTION
Наблюдение: один модуль потенциально объединяет индекс, maps, comparator и дальнейшие embedding providers.
Риск: вместо экономии получить универсальную indexing platform.
Проверка: S1 на одном declared scope, transient lexical index, existing graph data; no provider framework до второго реального backend.
Уверенность: высокая.

### ⚠️ BLIND SPOT — COHERENCE ≠ TRUTH
Наблюдение: связный Target/Observed graph выглядит как доказательство реализованной архитектуры.
Риск: ложный PASS, false missing при partial extraction и неверный code fix.
Проверка: отдельные tests на top-k miss, unsupported parser, future expectations, test-file-without-run и unconfirmed mapping.
Уверенность: высокая.

Новых Human Gates не предлагается. Сам module не заменяет quality checks реальной разработки. Unknowns IG-01–05 имеют узкие resolution actions в ТЗ, а не блокируют всё.

## 7. Review outcome

**Рекомендация:** один packaged module, два capability contracts, общий разрешённый corpus и раздельные outputs. Создать только отсутствующую candidate registration после current inventory check; не дублировать существующий project graph или FTR-017.

**Не подтверждено:** фактическая экономия, runtime compatibility, полнота существующей AS-IS карты, implementation conformance, first-host support. Их статусы `UNKNOWN` / `NOT_RUN`, не PASS. Самостоятельная проверка документов не является Independent Audit.
