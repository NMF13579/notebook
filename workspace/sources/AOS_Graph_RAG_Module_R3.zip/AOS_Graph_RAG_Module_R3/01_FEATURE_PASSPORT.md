# Feature Candidate — Graph Work Companion · R3

```yaml
candidate_id: CAND-GRAPH-WORK-001
feature_id: UNASSIGNED
name: Graph Work Companion
revision: R3
status: GENERATED_DRAFT
layer: Development support / product interaction
synthesis_recommendation: SIMPLIFY
human_disposition: UNDECIDED
product_scope_effect: NONE_UNTIL_HUMAN_DECISION
runtime_verification: NOT_RUN
implementation_authorization: NONE
git_authorization: NONE
```

## 1. Проблема и целевой результат

Пользователь управляет разработкой, но агент повторно ищет одни источники, теряет связи между контрактом/данными/реализацией/тестами и может работать по устаревшей карте. Пользовательский запрос подтверждает желаемое направление: эффективное недорогое применение Graph + RAG для качественной разработки. Количественная частота failures и экономия пока не измерены. [P-01–03]

Результат: по выбранной задаче показать **что предусмотрено, что наблюдалось, что не проверено, где расходится и какие источники нужны для следующего действия**. Качество определяется корректностью завершённой разработки, а не числом узлов, retrieved chunks или скоростью генерации.

Users: non-programmer product owner; оператор coding agent; existing development agent; reviewer. Основная среда — локальный проект с файлами и уже используемым агентом.

## 2. Фича уже есть или нужна новая?

| Объект | Наблюдение / решение-кандидат |
|---|---|
| Проектный граф AOS-3 | Есть architectural owner §18 и AS-IS reference. Повторно использовать его IDs/vocabulary и существующие источники. Не переписывать ради нового названия. |
| Graph Work R2 | Есть точный draft в чате. R3 продолжает тот же `candidate_id`; не доказывает существование этой Feature в canonical inventory. |
| Коробочная Graph Feature | В проверенном индексе 31 Feature отдельной записи не найдено. Подготовить одну candidate-запись; final FTR ID назначается при отдельном inventory action после проверки текущей ветки. |
| FTR-017 | Уже есть retrieval capability. Не заводить «ещё одну RAG Feature»; предложить feature-specific bounded Product Contract. |

**Не использовать `FTR-031`:** он уже занят cross-platform preflight. Не считать `FTR-032` зарезервированным только потому, что текущий индекс содержит 31 пункт. [R-03]

## 3. Границы capability и ownership

| Capability / fact class | Единственный owner | Что добавляет пакет |
|---|---|---|
| Accepted expectation | Применимые Product/Design/ADR источники | Derived Target, без нормотворчества |
| Observed repository | Instrumental source observation | Derived Observed, typed support и coverage |
| Graph comparison | Graph Product Contract Candidate | Mapping, Delta и routing к существующему owner |
| Retrieval | FTR-017 proposed bounded contract | Source/fragment candidates; graph expansion как способ поиска |
| Task DAG/selection | FTR-007 и task owners | Только потребление, без второго scheduler |
| Context assembly | FTR-016 | Предварительный retrieval снаружи pure owner |
| Verification/human decision | Existing result/review owners | Ссылки и точная атрибуция, не собственные PASS/approval |
| Registry authenticity/global drift controls | FTR-021 scope | Не реализовывать весь governance механизм внутри Graph |
| Packaging/extensions | Existing portable/install owners | Bundled optional code; не требуется весь FTR-026 framework |

Один runtime package вправе реализовать несколько capability boundaries. Два Product Contract не должны взаимно зависеть: graph работает без advanced retrieval; retrieval работает без полной карты. Совместимость связывается в ТЗ/Engineering Design, а не cyclic normative references.

## 4. Trigger, вход и выход

Trigger: «покажи связи/расхождения», «подготовь контекст», «что затронет изменение», «продолжи после перерыва». Простую точечную задачу не надо принудительно раскладывать в граф.

Вход: выбранная цель/граница; owner artifacts и их status; разрешённый source capture; явные mapping/dependencies; результаты проверок; доступные budget/usage. Выход: Target/Observed/Delta либо честная partial view; compact source-grounded packet; одно следующее действие; source-bound continuation refs.

## 5. Минимальный пользовательский путь

1. Пользователь выбирает проект и задачу обычным языком в поддерживаемом host.
2. Модуль получает разрешённый corpus без отправки всего кода модели.
3. Exact/lexical search находит anchors; typed graph добавляет ограниченное окружение.
4. При вопросе о соответствии выполняется отдельное сравнение expectations и observations; обычный поиск не обязан запускать Delta.
5. Агент получает packet с обязательными owners, исходными фрагментами и ограничениями; дальнейшая разработка идёт по уже действующему процессу.
6. После результата или новой сессии проверяется применимость данных и показывается next action, а не автоматическое повторение mutation.

## 6. Failures и recovery

Stale capture → refresh affected scope или historical view. Unsupported parser → lexical fallback, structural claim `UNVERIFIED`. Ambiguous mapping → уточнение, не code fix. Budget exceeded → сужение optional context, не удаление обязательных правил. Concurrent save → не перетирать чужую revision. Missing host/read route → ограниченный экспорт, не обещание коробочного полного пути.

## 7. Acceptance и не-цели

Graph criteria принадлежат `02_GRAPH_PRODUCT_CONTRACT.md`; retrieval criteria — `03_RETRIEVAL_PRODUCT_CONTRACT.md`. Здесь только ссылки, не третий нормативный набор. Связь criteria ↔ executable scenarios — в verification.

Не-цели: самостоятельный multi-agent runtime, scheduling, автоматический merge, принятие дизайна по графу, обязательные embeddings, гарантия полной семантики кода, бессрочно свежая «память».

## 8. Candidate для будущего внесения в inventory

Предлагаемая формулировка новой строки после проверки отсутствия equivalent Feature:

> `<human-assigned FTR ID>` — Graph Work Companion: source-bound Target/Observed/Mapping/Delta, task/resource navigation и подготовка контекста existing agent; `human_disposition: UNDECIDED`, `synthesis_recommendation: SIMPLIFY`.

Развёрнутый dossier — данный паспорт. Для FTR-017 добавить ссылку на отдельный candidate contract, не менять disposition и не выбирать advanced backend автоматически. `feature_count` изменять только вместе с реально внесённой строкой. Сохранение draft в `development/` само по себе не изменяет canonical inventory.
