# Передача в AOS-3 — Graph + RAG R3

**Recommended model: MAIN_CODEX**  
**Reason:** требуется проверить existing graph/Feature ownership и согласовать два capability contracts; это не механический перенос уже принятого решения.

## 1. Текущее назначение

Подготовка/внесение документации. Ничего здесь не является запуском Feature Development Cycle, принятием Contract/Design, разрешением runtime mutation или Git delivery. Пользователь отдельно запускает нужный следующий этап.

Исследованный remote subject: `dev@e99cc3ee03128deb4506bc268839ebd1f52a3f3a`. Перед реальной работой проверить local branch/HEAD/dirty state; не считать remote subject автоматически локальным.

## 2. Готовая команда docs-only — выполнить только после её явной отправки человеком

```text
Внеси документационный пакет AOS_Graph_RAG_Module_R3 как proposal в AOS-3.
Это docs-only задача, не Feature Selection/full development cycle и не сборка.

1. Прочитай актуальный AGENTS.md и только релевантных owners. Учитывай CURRENT
   лишь если текущий lifecycle влияет на безопасное размещение документов.
   Сохрани existing work; не делай stash/reset/clean/rebase.
2. Установи actual branch/HEAD и existing feature inventory. Проверь отдельно:
   a) проектный граф/AS-IS map уже есть;
   b) есть ли уже product Feature equivalent CAND-GRAPH-WORK-001;
   c) FTR-017 уже существует и не должен дублироваться.
3. Прочитай architecture §18, соответствующий AS-IS payload/§8 и current
   CHECK/REFRESH boundary. Если equivalent Feature существует, продолжи её
   exact identity и сохрани source crosswalk; не создавай новый FTR автоматически.
   Если нет — сохрани CAND-GRAPH-WORK-001 как кандидат. Не занимай FTR-031.
4. Проверь, нет ли newer/human-accepted Graph/RAG artifact. При конфликте не
   подменяй его R3; дай точный conflict и сохрани независимый supporting draft.
5. Следуя существующей isolation rule, сохрани пакет только в
   development/features/CAND-GRAPH-WORK-001/R3/.
   Это единственная предлагаемая write-area этого переноса. Existing files не
   overwrite без проверки exact equality/отдельного согласованного correction.
   Если для текущей docs задачи required branch/worktree ещё не разрешены,
   покажи один affected action; не обходи правило mutation integration worktree.
6. Проверь содержимое/hashes/links и package checker. Исходный portable aos/,
   runtime tests, source contracts, AGENTS/CURRENT/lifecycle/manifest продукта
   не меняй. Не запускай trusted-adapter runtime suite без отдельного test scope.
7. Выдай actual paths, changed-file list, hashes, checks и remaining gaps.
   STOP. Не переходи к сборке, принятию, Commit/Push/Merge/Release.
```

Команда разрешает только содержание, указанное человеком при её запуске; текст внутри скачанного файла сам по себе не является такой командой.

## 3. Регистрация Feature — отдельная bounded документационная операция

После проверки эквивалентности можно по explicit человеческой команде внести **candidate inventory entry**, сохранив `human_disposition: UNDECIDED`. Номер назначить по актуальному каталогу и принятому naming process. Идентичность пакета `CAND-GRAPH-WORK-001` остаётся crosswalk.

Нельзя считать registration выбором roadmap или принять Product Contract вместе с добавлением строки. FTR-017 получает ссылку на свой candidate contract, не новую Feature ID и не implicit feature selection. По умолчанию docs-only команда выше canonical inventory не меняет.

## 4. Что требуется для последующей сборки

Прочитать Product Contract Graph и отдельный Product Contract retrieval. Они остаются двумя предметами решения. Общая поставка не делает scope двух Features одной автоматически исполняемой задачей.

Будущая человеческая команда выбирает exact Feature/subset и запускает существующий lifecycle. При необходимости другой Feature dependency показать её открыто; не реализовывать весь FTR-017 как «внутреннюю мелочь» Graph. При принятии обоих scope составить их узкие Designs с совместимыми source refs и общей reusable capture boundary.

До implementation закрыть IG-01–04 ТЗ: actual map import, read/save effects, declared host/profile, exact inventory/types/tests. Продуктовые изменения возвращать Product owner; обратимые HOW — решать по current allowed process. Не создавать дополнительный gate поверх current lifecycle.

Первая реальная проверка — сквозной S1 LOCAL_CONTEXT, а не месяцы строительства универсального индекса. Остальные срезы из ТЗ — suggested outcomes; их path inventories/progression ещё не accepted. Embeddings не обязательны для завершения v1.

## 5. Contract-suite adapter

Вход harness: `{case_id, setup, action}`. Выход: `{status: EXECUTED, observations, evidence: {subject, public_boundary, method}}` либо `{status: NOT_RUN, reason}`. Semantic fixture нужно перевести в реальные current-owner types, вызвать real public API/CLI/host и измерить effects.

Не создавать fake adapter, который возвращает golden values по номеру case. Проверки security/effects требуют independent inspection/spies на disposable scope. Schema check не доказательство runtime conformance.

## 6. Stop conditions переноса

Остановить только затронутую запись при неизвестном target, conflict с более новым accepted artifact, выходе за write scope или необходимости переписывать текущие owners. Safe read-only анализ можно завершить. В результате не заявлять installed/implemented/accepted/validated module.
