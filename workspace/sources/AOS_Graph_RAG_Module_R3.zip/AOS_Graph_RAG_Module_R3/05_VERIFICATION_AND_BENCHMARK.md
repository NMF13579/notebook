# Verification и эксперимент качества/стоимости

**Статус:** `PROPOSED_VERIFICATION_PLAN`. Runtime, benchmark и независимый аудит не выполнены. Проверки документов/JSON не заменяют их.

## 1. Предметы проверки

Graph: AC-01–38 в `02_GRAPH_PRODUCT_CONTRACT.md`. Retrieval: RA-01–24 в `03_RETRIEVAL_PRODUCT_CONTRACT.md`. ТЗ не вводит третий независимый Product Contract. Все runtime сценарии находятся в `verification/contract_cases.json`; tests R2 GW-T01–70 сохранены, добавлены GW-T71–72 и RG-T01–24.

`verification/run_contract_suite.py` — harness, который передаёт semantic fixture/action explicit trusted implementation adapter. **Это не тестируемый runtime и не oracle correctness сам по себе.** Адаптер обязан вызвать фактическую public boundary, получить реальные observations и сохранить evidence. Возврат ожидаемых полей по `case_id` без запуска системы недопустим. Без адаптера — `NOT_RUN`, exit 3.

## 2. Группы и метод

| Проверка | Наблюдаемое основание |
|---|---|
| Source boundary | Read spies/sentinels, разрешённые/запрещённые пути и отсутствие network/process effects |
| Retrieval | Точный source revision/span/snippet; repeated request order; mandatory source inclusion |
| Graph traversal | Реальные направленные рёбра и bound support refs; ограничение expansion; отсутствие hidden nodes |
| Comparator | Позитивные witnesses и покрытие отрицательных assertions, не top-k results |
| Refresh | Create/edit/delete/rename, dirty same HEAD, worktree separation, изменившийся source policy |
| Persistence | Подтверждённый save/readback, separate new process, conflict/partial-save и сохранение прошлой revision |
| Cost | Process/model/tool invocations, exact serialized bytes, actual usage или UNKNOWN |
| Packaging | Копия только `aos/` + declared dependencies/host, без `development/` |

Инструментальная проверка effects выполняется на disposable subject. Это не разрешает runtime tests изменять настоящий пользовательский репозиторий. Исходные owner contracts читаются, но не «чинятся» validation.

## 3. Обязательный сквозной installed сценарий

Исходный fixture содержит малый документ с принятой для **синтетического теста** current expectation, два Python файла, тестовый файл, explicit relation и future requirement. Это тестовые данные, не запись реального human acceptance.

1. Установить точный candidate в отдельно созданный disposable target через admitted install route. Record profile, source identity и доступные host tools.
2. Пользовательский запрос обычным языком: «Что затронет изменение экспорта и какие проверки нужны?» Host вызывает фактическую публичную module boundary без ручного JSON пользователя.
3. Убедиться: exact contract/code anchors найдены; typed graph добавил связанную проверку; packet содержит constraints и citations; source bodies за пределами packet не переданы модели.
4. Сравнить известное current expectation с полным mapped source-set. Найти одну запрещённую явную связь; future отсутствие не назвать дефектом; тестовый файл без execution record не назвать PASS.
5. Изменить source без commit, добавить файл с новым incoming relation и удалить старый. Новый запрос должен получить новые/инвалидированные source units, не stale-as-current.
6. Завершить процесс; открыть новую сессию с сохранёнными permitted refs. Проверить восстановление task context без прежнего чата, fresh capture и отсутствие replay неизвестного action.
7. Отключить модуль/удалить disposable cache по разрешению. Обычный AOS flow остаётся доступным, human decision records не изменены.

Required E2E не закрывается тестом pure function со вручную идеально подготовленным corpus. Для RAG часть generation-host должна действительно получить packet и дать source-attributed ответ; сами утверждения проверяются against fixtures, а не моделью «мне кажется правильно».

## 4. Material negative/failure matrix

Обязательны: скрытая/исключённая ссылка в graph path; prompt injection в документе; invented IMPLEMENTS по имени; semantic similarity как identity; top-k miss как false missing; partial parser support; empty target/empty coverage; same-HEAD dirty change; новый файл с входящим dependency; conflicting target/owner; hidden remote fallback; stale lexical vs fresh graph и наоборот; concurrent cache publisher; interrupted unknown action; output budget меньше mandatory packet; wrong worktree; deleted source cached snippet; module disabled; corrupted cache.

Общий graph cycle не является task-DAG violation. Исторический PASS остаётся связанным с прежним subject. Нельзя получить универсальный completion score из MATCHED edges.

## 5. Бounded benchmark: сначала дешёвая проверка

Первый пилот — один известный многосоставной запрос на exact scope, без нового parser framework. Затем сравнить:

- A: текущий агент + direct search;
- B: тот же агент + lexical retrieval;
- C: тот же агент + lexical + graph context;
- D: semantic/hybrid extension — только если B/C показали конкретный recall gap, не обязательный этап.

Набор: простой exact-file fix; поиск контракта по русскому описанию с английским ID; изменение интерфейса с потребителями; отличие current/future design; возобновление после dirty change; неполное наблюдение/неоднозначный mapping. Для проверки пользы Delta на одном сложном случае сравнить C с/без comparator.

Одинаковые snapshot, source access, model/settings и success criteria; независимые процессы/контексты; чередование порядка. Любая подготовка карты и идеального mapping включается в C. Cold build отдельно, warm reuse отдельно, refresh отдельно. Не выбирать только удачный stochastic run. Число повторов и budget определить до запуска bounded task; при исчерпании — INCONCLUSIVE, не бесконечный benchmark.

### Метрики

| Ось | Метрика и оговорка |
|---|---|
| Correctness разработки | Независимые acceptance/negative checks на actual changed subject; module navigation PASS не заменяет их |
| Context quality | Recall@k на размеченных нужных source spans, обязательные источники отдельно, ложные/устаревшие включения |
| Impact / Delta | Подтверждённые/пропущенные/ложные расхождения, unknowns отдельно |
| Effort | Чтения/байты, число clarification/replanning, human coordination/review minutes |
| Cost | Все observed model tokens/calls, failed attempts, build/refresh/repair; unknown значения не нули |
| Latency | Cold/warm/check/refresh и query отдельно; локальное чтение не объявлять бесплатным |
| Durability | Правильный resume и отсутствие double-count/replay |

```text
C_total = setup + indexing + refresh + model_attempts + review + repair
C_per_validated_result = C_total / independently_validated_results
```

При нуле validated results отношение не определено. На подписке tokens/квоту нельзя молча пересчитывать в деньги как API. Полная цена неизвестна → денежный вывод UNKNOWN, но измеренное effort улучшение можно показать.

**Предлагаемый ориентир pilot:** без новых material correctness/safety defects, с сохранением mandatory source coverage и уменьшением медианы полной наблюдаемой стоимости либо human coordination на 20%. Малый pilot подтверждает только tested scope. Результат `BENEFIT_IN_TESTED_SCOPE`, `NO_BENEFIT_IN_TESTED_SCOPE` или `INCONCLUSIVE`; это экспериментальные выводы, не новые lifecycle statuses/gates.

## 6. Что запускать сейчас и позже

Сейчас допустимы проверки сформированного пакета в отдельной conversation sandbox. Они проверяют links, criteria/test coverage, schema shape, example consistency, fixture identities и hashes, не module behavior.

```bash
python -B verification/check_package.py
python -B verification/run_contract_suite.py
# Вторая команда без adapter обязана вернуть NOT_RUN и exit 3.
```

Позже, только на разрешённом disposable subject: explicit trusted adapter и actual SUT.

```bash
python -B verification/run_contract_suite.py --adapter python /exact/approved/test_adapter.py
```

При timeout harness останавливает дальнейшие cases; возможные subprocess descendants/effects должен сверить владелец adapter. Harness не sandbox и не system security boundary. Unavailable required runtime check не превращается в PASS.

## 7. Статус этой подготовки

Объектные схемы и fixtures — предложенная инженерная спецификация, не public API AOS. Running package checker не подтверждает качество extractor, atomic save, отсутствие leaks в host или экономию RAG. Эти проверки требуют будущего accepted candidate, точного профиля и воспроизводимого Evidence.
